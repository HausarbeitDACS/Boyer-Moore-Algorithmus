# __init__.py
from boyer_moore_algorithmus.boyer import *

